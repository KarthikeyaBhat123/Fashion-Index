import React, { Component } from "react";
import Header from "./header/Header";
import { bindActionCreators } from "redux";
import { Home } from "./Redux/Actions/HomeActions";
import { connect } from "react-redux";

const mapStateToProps = (state) => {
	return { roles: state.Home };
};

const mapDispatchToProps = (dispatch) => ({
	actions: bindActionCreators(
		{
			Home,
		},
		dispatch
	),
});

class App extends Component {
	constructor(props) {
		super(props);
		this.state = {
			roles: {},
			fetchInProgress: true,
		};
	}

	render() {
		// this.props.actions.Home(this.state);

		return <Header></Header>;
	}
}
export default connect(mapStateToProps, mapDispatchToProps)(App);
